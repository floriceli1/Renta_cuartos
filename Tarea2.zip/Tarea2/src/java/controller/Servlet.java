/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import beans.sesion;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author labso09
 */
public class Servlet extends HttpServlet {

   

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
         sesion s=new sesion();
         s.setUsuario(request.getParameter("usuario"));
         s.setRol(request.getParameter("rol"));
         s.setNombre(request.getParameter("nombre"));
         s.setJefe(request.getParameter("jefe"));
         s.setContrasena(request.getParameter("contrasena"));
         out.println("           ");
         out.println("usuario:"+s.getUsuario());
         out.println("           ");
         out.println("Rol:"+s.getRol());
         out.println("           ");
         out.println("Nombre:"+s.getNombre());
         out.println("           ");
         out.println("Jefe:"+s.getJefe());
         out.println("           ");
         out.println("contraseña:"+s.getContrasena());
         
//         RequestDispatcher dispatcher
//                = request.getRequestDispatcher("pages/Registrar.jsp");
//       dispatcher.forward(request, response);
       
    }

 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

  
}
